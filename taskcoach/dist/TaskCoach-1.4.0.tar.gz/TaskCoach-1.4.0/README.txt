================================================================
Task Coach - Your friendly task manager
================================================================

Version 1.4.0, August 28, 2013

By Frank Niessink, Jerome Laheurte, and Aaron Wolf <developers@taskcoach.org>

http://taskcoach.org/

Copyright (C) 2004-2013 Frank Niessink, Jerome Laheurte, and Aaron Wolf
GNU General Public License version 3 or any later version

================================================================
