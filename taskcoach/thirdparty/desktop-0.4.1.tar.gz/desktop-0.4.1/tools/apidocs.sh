#!/bin/sh

epydoc --docformat=plaintext -o apidocs desktop
