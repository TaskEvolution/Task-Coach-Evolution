'''
Run tools\depgraph.py on this file to get dependency graph of pubsub. 
'''
import pubsub
import sys
from pubsub import pub
print pubsub.__file__
#from pubsub import pub