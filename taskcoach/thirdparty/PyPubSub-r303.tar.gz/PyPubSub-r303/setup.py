#from distutils.core import setup
import ez_setup
ez_setup.use_setuptools()

from setuptools import setup, find_packages

# use the module docs as the long description: 
longDesc = file('cheese.txt', 'r').read()

packages = find_packages('src')
print '*'*40
print packages
print '*'*40

setup(
    name         = 'PyPubSub',
    version      = '3.2.0b',
    description  = 'Python Publish-Subscribe Package',
    author       = 'Oliver Schoenborn et al',
    author_email = 'oliver.schoenborn@gmail.com',
    url          = 'http://pubsub.sourceforge.net',
    download_url = 'http://downloads.sourceforge.net/pubsub',
    packages     = packages,
    package_dir  = {'pubsub': 'src/pubsub'},
#    scripts      = [],
    license      = "BSD",
    zip_safe     = False,
    #include_package_data = True,
    keywords     = "publish subscribe observer pattern signal signals event events message messages messaging",
    classifiers  = [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: Python Software Foundation License',
        'Natural Language :: English',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    long_description = longDesc
)


