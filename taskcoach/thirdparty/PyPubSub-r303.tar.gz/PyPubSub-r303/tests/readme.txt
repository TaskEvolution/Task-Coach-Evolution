There are three sets of tests:

1. test pubsub_kwargs: kwargs messaging protocol (the pubsub default)
2. test pubsub_arg1: arg1 messaging protocol

Tests in this folder can be run via runtests.bat. The other test
folders should be run separately (cd to folder and run nosetests).