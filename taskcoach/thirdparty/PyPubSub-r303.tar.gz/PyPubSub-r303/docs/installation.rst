Installation
===============

Look at the system requirements (below), and the license. Then head on
to the :ref:`label-download` section. Community :ref:`label_support` is
available via forums.


.. _label-download:

Download
----------

.. note::  Latest release: 3.1.2


Choose ONE of the following download/install methods:

3. Manually:

   - Download the `appropriate source distribution
     <http://sourceforge.net/projects/pubsub/files/pubsub/>`_
     from SourceForge.net
   - From a console window, do :command:`python setup.py install` 
   

.. _label_support:

Support
--------

The forums are currently hosted on google groups:

- General help and support: on the
  `PyPubSub <http://googlegroups.com/group/pypubsub>`_
  Google group (http://googlegroups.com/group/pypubsub)

- Bug reports, feature suggestions, patches, docs, etc: on
  `PyPubSubDev <http://googlegroups.com/group/pypubsub_dev>`_
  Google group (http://googlegroups.com/group/pypubsub_dev)

Also, many pubsub users are on the wxPython-users mailing list, at this time
still has the largest pool of users: http://www.wxpython.org/maillist.php.


Other Info
-----------

.. toctree::

   changelog

