Pubsub's Setup Modules
========================



Kwargs Messaging Protocol
--------------------------

The *kwargs* protocol is defined as follows:

- the transport of all topic message data occurs via keyword arguments
  in sendMessage(); the argument names must be the same for all
  sendMessage() for a given topic.

- the listener's parameters must be named the same as the keyword
  arguments used in sendMessage()

- subtopics can only extend the list of argument names accepted

Example: assume a topic 'someTopic' and subtopic 'someTopic.subTopic'::

    from pubsub import pub

    def listener(hi): assert hi == 123
    pub.subscribe(listener, 'someTopic')

    def listener2(hi, foo): assert hi == 123; assert foo == 'bar'
    pub.subscribe(listener2, 'someTopic.subTopic')

    pub.sendMessage('someTopic.subTopic', hi=123, foo='bar')


Arg1 Messaging Protocol
------------------------

This protocol
is defined as follows:

- the transport of all topic message data occurs as one user-defined
  Python object, stored in the .data attribute of the object received
  by listeners

- the listener must accept being called as f(message)

Example::

    from pubsub import setuparg1
    from pubsub import pub
    def listener(msg): assert msg.data['hi'] == 123
    data = {'hi':123, ...} # replace ... with whatever you want
    pub.sendMessage('someTopic', data)

