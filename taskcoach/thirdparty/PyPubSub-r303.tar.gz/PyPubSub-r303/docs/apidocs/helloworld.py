'''
One listener is subscribed to a topic called 'rootTopic'.
One 'rootTopic' message gets sent. 
'''

from pubsub import pub

# ------------ create a listener ------------------

def listener1(arg1, arg2=None):
    print 'Function listener1 received:\n  arg1="%s"\n  arg2="%s"' % (arg1, arg2)

# ------------ register listener ------------------

pub.subscribe(listener1, 'rootTopic')

#------ create a function that sends a message ----

def doSomethingAndSendResult():
    print 'lahdida... have result, publishing it via pubsub'
    pub.sendMessage('rootTopic', arg1=123, arg2=dict(a='abc', b='def'))

# --------- define the main part of application --------

if __name__ == '__main__':
    doSomethingAndSendResult()
