.. _label-usage:

API Documentation
====================

.. warning::

   This documentation is in the process of being updated. You may find 
   it more useful to refer to the
   source code doc strings and the examples in the :file:`examples`
   folder of the source distribution.


.. _label-api-v3-docs:

The User Guide consists of the following sections:

.. toctree::
   :maxdepth: 2

   examples
   basic_use
   more_advanced_use

Status 
^^^^^^^

Pubsub's public API is provided via its 'pub' and 'utils' modules. 
The following part of this API is unlikely to change:

Messaging, basic: 

- pub.sendMessage
- pub.subscribe
- pub.ALL_TOPICS
- pub.AUTO_TOPIC

Topic specification: 

- pub.addTopicDefnProvider
- pub.clearTopicDefnProviders
- pub.setTopicUnspecifiedFatal

Notification handling: 

- utils.useNotifyByWriteFile
- utils.printTreeDocs
- pub.addNotificationHandler
- pub.clearNotificationHandlers

Listener Exception handling: 

- pub.getListenerExcHandler
- pub.setListenerExcHandler
- pub.ExcHandlerError

Exceptions: 

- pub.ListenerInadequate
- pub.ListenerNotValidatable
- pub.ListenerSpecIncomplete
- pub.ListenerSpecInvalid
- pub.SenderMissingReqdArgs
- pub.SenderUnknownOptArgs
- pub.UndefinedSubtopic
- pub.UndefinedTopic

Messaging, advanced: 

- pub.getAssociatedTopics
- pub.getDefaultPublisher
- pub.getDefaultTopicMgr
- pub.getListenerID
- pub.getTopic
- pub.isSubscribed
- pub.isValid
- pub.Listener
- pub.Publisher
- pub.Topic
- pub.topics
- pub.topicsMap
- pub.unsubAll
- pub.unsubscribe
- pub.validate

Versioning: 

- pub.SVN_VERSION
- pub.VERSION_STR
- pub.PUBSUB_VERSION

The following, related to Topic Specification, are likely to evolve:

- pub.TOPIC_TREE_FROM_CLASS
- pub.TOPIC_TREE_FROM_MODULE
- pub.TOPIC_TREE_FROM_STRING
- pub.exportTopicTree
- pub.importTopicTree
- pub.ITopicDefnProvider
- pub.ITopicTreeTraverser
- pub.registerTopicDefnProviderType
- pub.TopicDefnProvider


